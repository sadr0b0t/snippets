ov7670test
==========

LPCXpresso project for working with the ov7670 camera sensor.

For details on what this is about, see:

http://qrfnfgre.wordpress.com/2012/05/07/ov7670-camera-sensor-success/
