#ifndef __DELAY_H 
#define __DELAY_H

void delay(int n);

#endif

/* vim: set et sw=4: */
